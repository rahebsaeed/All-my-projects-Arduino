# My First Project > 2025-05-09 3:27pm
https://universe.roboflow.com/non-2ajui/my-first-project-rx9zn

Provided by a Roboflow user
License: CC BY 4.0

