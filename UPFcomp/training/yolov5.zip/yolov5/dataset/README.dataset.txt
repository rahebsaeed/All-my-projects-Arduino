# cubeDetection > 2025-05-10 1:03pm
https://universe.roboflow.com/non-2ajui/cubedetection-1uha1

Provided by a Roboflow user
License: CC BY 4.0

